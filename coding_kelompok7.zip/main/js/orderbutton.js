const priceElement = document.getElementById("price");
const quantityElement = document.getElementById("quantity");
const totalElement = document.getElementById("total");

// Set initial values
let price = 10; // Example price
let quantity = 1;

// Update the quantity and total based on user input
function updateQuantity(value) {
    quantity = parseInt(value) || 1;
    quantityElement.textContent = quantity;
    updateTotal();
}

// Update the total based on the price and quantity
function updateTotal() {
    const total = price * quantity;
    totalElement.textContent = total;
}

// Update the quantity when user inputs a value
const inputElement = document.createElement("input");
inputElement.addEventListener("input", (event) => {
    updateQuantity(event.target.value);
});
document.body.appendChild(inputElement);